-- Enable RLS
ALTER DATABASE neondb SET row_security = on;

-- Create profiles table
CREATE TABLE profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_guest BOOLEAN NOT NULL DEFAULT true,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  language TEXT DEFAULT 'en',
  country TEXT
);

-- Create resources table
CREATE TABLE resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  summary TEXT,
  content TEXT,
  category TEXT,
  topic_tags TEXT[],
  language TEXT DEFAULT 'en',
  is_published BOOLEAN DEFAULT false,
  is_offline_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create emergency_contacts table
CREATE TABLE emergency_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  region TEXT,
  category TEXT,
  is_24_7 BOOLEAN DEFAULT false,
  notes TEXT
);

-- Create mood_entries table
CREATE TABLE mood_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  mood_score INTEGER NOT NULL,
  mood_label TEXT,
  note TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  synced BOOLEAN DEFAULT false
);

-- Create sobriety_entries table
CREATE TABLE sobriety_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  entry_type TEXT NOT NULL, -- e.g., 'start', 'relapse'
  date DATE NOT NULL,
  notes TEXT,
  synced BOOLEAN DEFAULT false
);

-- Create journal_entries table
CREATE TABLE journal_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT,
  body_encrypted TEXT, -- Store encrypted locally, or use Neon for sync
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  synced BOOLEAN DEFAULT false
);

-- Create anonymous_questions table
CREATE TABLE anonymous_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_text TEXT NOT NULL,
  topic TEXT,
  status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  moderation_flag BOOLEAN DEFAULT false
);

-- Create answers table
CREATE TABLE answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id UUID REFERENCES anonymous_questions(id) ON DELETE CASCADE,
  answer_text TEXT NOT NULL,
  reviewed_by TEXT, -- Admin user ID or name
  published_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on tables with user data
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE mood_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE sobriety_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;

-- RLS Policies (example: users can only access their own data)
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id OR is_guest = true);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id OR is_guest = true);
-- Add similar policies for other tables (e.g., mood_entries: auth.uid() = user_id)

-- Note: For guest users, allow anonymous access where needed, but restrict sensitive data.