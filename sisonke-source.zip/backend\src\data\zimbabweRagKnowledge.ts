export type SafetyRoute = 'self_harm' | 'active_violence' | 'sexual_assault' | 'forced_marriage' | 'substance_emergency';

export type SafetyRule = {
  route: SafetyRoute;
  risk: 'red' | 'amber';
  terms: string[];
};

export type ZimbabweContact = {
  id: string;
  name: string;
  phoneNumber: string;
  category: string;
  description: string;
  country: 'ZW';
};

export type KnowledgeCard = {
  id: string;
  title: string;
  category: 'mental-health' | 'srhr' | 'emergency' | 'substance-use' | 'wellness' | 'guide';
  tags: string[];
  riskLevel: 'green' | 'amber' | 'red';
  content: string;
};

export const zimbabweEmergencyContacts: ZimbabweContact[] = [
  {
    id: 'zw-childline-116',
    name: 'Childline Zimbabwe',
    phoneNumber: '116',
    category: 'child-protection',
    description: 'Free 24-hour child and teen support. Childline also publishes WhatsApp support on +263 719 116 116 and +263 732 116 116.',
    country: 'ZW',
  },
  {
    id: 'zw-musasa-econet',
    name: 'Musasa GBV Hotline',
    phoneNumber: '08080074',
    category: 'gbv',
    description: '24-hour support for gender-based violence, domestic violence, counseling, legal advice, shelter referral, and post-rape care referral.',
    country: 'ZW',
  },
  {
    id: 'zw-musasa-netone',
    name: 'Musasa GBV Hotline NetOne',
    phoneNumber: '08010074',
    category: 'gbv',
    description: '24-hour Musasa support line for NetOne users.',
    country: 'ZW',
  },
  {
    id: 'zw-musasa-telecel',
    name: 'Musasa GBV Hotline Telecel',
    phoneNumber: '0731080074',
    category: 'gbv',
    description: '24-hour Musasa support line for Telecel users.',
    country: 'ZW',
  },
  {
    id: 'zw-adult-rape-clinic',
    name: 'Adult Rape Clinic',
    phoneNumber: '08080472',
    category: 'sexual-assault',
    description: '24-hour toll-free sexual assault medical, counseling, legal, and Victim Friendly Unit linked support. Seek care quickly because PEP is time-sensitive.',
    country: 'ZW',
  },
  {
    id: 'zw-friendship-bench',
    name: 'Friendship Bench',
    phoneNumber: '+263 784 845 294',
    category: 'mental-health',
    description: 'Free, confidential, non-emergency mental health support by WhatsApp for distress, anxiety, low mood, relationship strain, and substance misuse concerns.',
    country: 'ZW',
  },
  {
    id: 'zw-national-emergency',
    name: 'National Emergency Services',
    phoneNumber: '999',
    category: 'general',
    description: 'Use for immediate danger, urgent medical need, or police/emergency dispatch.',
    country: 'ZW',
  },
  {
    id: 'zw-police-mobile',
    name: 'Zimbabwe Republic Police',
    phoneNumber: '0772 235 461',
    category: 'general',
    description: 'Police emergency support. For sexual offences, domestic violence, or child abuse, ask for the Victim Friendly Unit at the nearest police station.',
    country: 'ZW',
  },
  {
    id: 'zw-ubh',
    name: 'United Bulawayo Hospitals',
    phoneNumber: '+263 292 252111',
    category: 'hospital',
    description: 'Public hospital emergency and casualty support for Bulawayo and the southern region. Mobile: +263 772 260 079.',
    country: 'ZW',
  },
  {
    id: 'zw-parirenyatwa',
    name: 'Parirenyatwa Group of Hospitals',
    phoneNumber: '+263 242 790067',
    category: 'hospital',
    description: 'Public hospital escalation point in Harare for urgent medical care.',
    country: 'ZW',
  },
];

export const safetyRules: SafetyRule[] = [
  {
    route: 'self_harm',
    risk: 'red',
    terms: [
      'suicide',
      'kill myself',
      'end my life',
      'want to die',
      'kuzviuraya',
      'hurt myself',
      'cut myself',
      'took pills',
      'overdose',
      'no reason to live',
      'i will do it tonight',
      'say goodbye to everyone',
    ],
  },
  {
    route: 'active_violence',
    risk: 'red',
    terms: [
      'he is hitting me',
      'she is hitting me',
      'they are beating me',
      'kurohwa',
      'not safe at home',
      'locked me in',
      'can hear him outside',
      'nceda',
      'help me now',
      'dad beats',
      'beating my mom',
      'domestic violence',
    ],
  },
  {
    route: 'sexual_assault',
    risk: 'red',
    terms: [
      'i was raped',
      'kubatwa chibharo',
      'forced me to have sex',
      'i said no',
      'sexual assault',
      'private parts',
      'bad touch',
      'uncle touches me',
      'need pep',
      'bleeding after sex',
      'he removed the condom',
    ],
  },
  {
    route: 'forced_marriage',
    risk: 'red',
    terms: [
      'forced marriage',
      'arranged marriage',
      'marry an older man',
      'married before 18',
      'child marriage',
      'family wants me to marry',
    ],
  },
  {
    route: 'substance_emergency',
    risk: 'red',
    terms: [
      'mutoriro',
      'guka',
      'dombo',
      'broncleer',
      'cough syrup',
      'musombodia',
      'kachasu',
      'friend collapsed',
      'took too much',
      'ku sticker',
    ],
  },
  {
    route: 'self_harm',
    risk: 'amber',
    terms: ['hopeless', 'depressed', 'panic', 'heart racing', 'heart is racing', 'can not cope', "can't cope", 'self harm', 'alone', 'empty', 'numb'],
  },
];

export const zimbabweKnowledgeCards: KnowledgeCard[] = [
  {
    id: 'zw-safe-place-protocol',
    title: 'Safe Place Protocol',
    category: 'emergency',
    tags: ['abuse', 'violence', 'danger', 'safety', 'childline', 'musasa', 'vfu'],
    riskLevel: 'red',
    content: 'If someone is in danger now, the bot must use one validating sentence, one urgent safety direction, and local contacts. Tell the user to move to the safest nearby place if it is safe to move: a room with other people, a neighbor, school office, clinic, church office, or trusted adult. Avoid kitchens, garages, or locked rooms. Do not tell a child to confront the abuser. Mention Childline 116, Musasa for GBV, Adult Rape Clinic for sexual assault, and the ZRP Victim Friendly Unit through the nearest police station.',
  },
  {
    id: 'zw-sexual-assault-pep',
    title: 'Sexual Assault Urgent Care',
    category: 'emergency',
    tags: ['rape', 'sexual assault', 'pep', 'adult rape clinic', 'musasa', 'vfu'],
    riskLevel: 'red',
    content: 'After rape or forced sex, medical care is urgent. The response should say this was not the user blame, and they should contact Adult Rape Clinic 08080472, Musasa, Childline 116 if under 18, or go to a clinic or hospital as soon as possible. HIV prevention medicine called PEP is time-sensitive and works best when started quickly, within 72 hours. Do not give forensic instructions that delay care.',
  },
  {
    id: 'zw-child-marriage-law',
    title: 'Marriage Under 18 Is Illegal',
    category: 'srhr',
    tags: ['marriage', 'child marriage', 'forced marriage', 'law', '18'],
    riskLevel: 'red',
    content: 'Zimbabwe law sets 18 as the minimum age for marriage. If a user under 18 is being pushed into marriage, treat it as a child-protection issue. Explain simply that the law protects them and no parent, guardian, partner, or traditional leader can force a child into marriage. Route them to Childline 116, Musasa if GBV is involved, or a trusted school or social services adult.',
  },
  {
    id: 'zw-under-18-sexual-protection',
    title: 'Sexual Protection for Under 18s',
    category: 'srhr',
    tags: ['consent', 'under 18', 'sexual abuse', 'law', 'safeguarding'],
    riskLevel: 'amber',
    content: 'For product safety, treat sexual situations involving users under 18 as safeguarding terrain. Zimbabwe has raised legal protection around sexual relations with children under 18. The bot should not shame the user. It should explain consent, pressure, and safety in plain words and route coercion, older partners, or abuse disclosures to Childline or a trained adult.',
  },
  {
    id: 'zw-abortion-law-care',
    title: 'Restricted Abortion Law and Safe Care',
    category: 'srhr',
    tags: ['pregnancy', 'abortion', 'rape', 'incest', 'clinic', 'law'],
    riskLevel: 'amber',
    content: 'Zimbabwe abortion law is restricted and legal details can change. The safe bot answer is not legal advice. Explain that termination is legally limited, including where the pregnancy endangers life or physical health, serious fetal impairment is involved, or pregnancy follows unlawful intercourse such as rape or incest. Tell the user not to try unsafe backyard abortion, and route them to a clinic, Adult Rape Clinic, Musasa, Childline, or legal-aid/counselor support for current guidance.',
  },
  {
    id: 'zw-youth-friendly-srhr',
    title: 'Youth Friendly SRHR Care',
    category: 'srhr',
    tags: ['contraception', 'condoms', 'clinic', 'privacy', 'confidential', 'youth friendly'],
    riskLevel: 'green',
    content: 'Young people deserve respectful, private, non-judgmental health care. For contraception, HIV testing, STI symptoms, pregnancy questions, or condoms, encourage a youth-friendly clinic or Youth Friendly Corner where available. Validate fear of stigma without reinforcing it. A practical next step is to ask the clinic: How will you keep my visit private?',
  },
  {
    id: 'zw-grounding-54321',
    title: '5-4-3-2-1 Grounding',
    category: 'mental-health',
    tags: ['panic', 'anxiety', 'stress', 'grounding', 'exams'],
    riskLevel: 'green',
    content: 'For panic or exam stress, give short steps: name 5 things you can see, 4 things you can touch, 3 things you can hear, 2 things you can smell, and 1 thing you can taste. Say this helps the mind come back to the room. If chest pain is severe, fainting happens, or the user may harm themselves, escalate to medical or crisis help.',
  },
  {
    id: 'zw-belly-breathing',
    title: 'Deep Belly Breathing',
    category: 'mental-health',
    tags: ['breathing', 'panic', 'sleep', 'stress', 'anxiety'],
    riskLevel: 'green',
    content: 'Explain deep belly breathing in Grade 7 language: put one hand on the chest and one on the belly. Breathe in through the nose so the belly rises. Breathe out slowly through the mouth. Repeat for five slow breaths. Say this tells the brain that the body is safer and can calm down.',
  },
  {
    id: 'zw-wall-push',
    title: 'Wall Push for Anger and Panic',
    category: 'mental-health',
    tags: ['anger', 'panic', 'frustration', 'grounding'],
    riskLevel: 'green',
    content: 'For high-energy panic, anger, or frustration, suggest the wall push if the user is physically safe: stand facing a wall, breathe in, push both hands into the wall while breathing out, then release. Repeat a few times. This uses big muscles safely and helps discharge stress.',
  },
  {
    id: 'zw-substance-local-names',
    title: 'Zimbabwe Substance Use Local Names',
    category: 'substance-use',
    tags: ['mutoriro', 'guka', 'dombo', 'mbanje', 'broncleer', 'musombodia', 'kachasu', 'cough syrup'],
    riskLevel: 'amber',
    content: 'Recognize local terms. Mbanje or ganja means cannabis. Mutoriro, guka, or dombo can mean crystal meth. BronCleer, Ngoma, or cough syrup can mean codeine misuse. Musombodia or kachasu are dangerous unregulated alcohols. If the user has collapsed, cannot breathe, has chest pain, extreme confusion, or took too much, escalate to emergency medical help immediately.',
  },
  {
    id: 'zw-substance-non-stigma',
    title: 'Substance Use Support Without Shame',
    category: 'substance-use',
    tags: ['drugs', 'addiction', 'rehab', 'peer pressure', 'recovery'],
    riskLevel: 'green',
    content: 'Substance dependence is a health issue, not a moral failure. Use respectful words. Encourage one trusted adult, clinic, counselor, Friendship Bench for non-emergency distress, or local rehabilitation pathways after verification. Do not give instructions on how to use drugs, mix substances, hide use, or manage overdose alone.',
  },
  {
    id: 'zw-healthy-relationships',
    title: 'Healthy and Unsafe Relationships',
    category: 'wellness',
    tags: ['relationships', 'jealousy', 'control', 'phone checking', 'boundaries', 'consent'],
    riskLevel: 'green',
    content: 'Healthy relationships have respect, trust, consent, privacy, and space for friends, school, family, and personal goals. Warning signs include checking phones, demanding passwords, isolating someone, threats, insults, pressure for sex, stalking, or jealousy that causes fear. If the user feels scared, controlled, or physically unsafe, move to safety planning and Musasa or Childline.',
  },
  {
    id: 'zw-digital-safety',
    title: 'Digital Abuse and Sextortion',
    category: 'wellness',
    tags: ['nudes', 'sextortion', 'revenge porn', 'blackmail', 'grooming', 'online abuse'],
    riskLevel: 'amber',
    content: 'Image-based abuse, sextortion, cyberbullying, and online grooming are serious. Tell the user not to send more images or money. Save evidence only if safe. Do not engage with threats if it increases danger. Contact Childline 116, a trusted adult, or police/VFU support. Never blame the user for being manipulated.',
  },
  {
    id: 'zw-persona-style',
    title: 'Sisonke E-Friend Persona',
    category: 'guide',
    tags: ['persona', 'style', 'ubuntu', 'hunhu', 'tone'],
    riskLevel: 'green',
    content: 'The assistant should sound like a caring older sister or brother in Zimbabwe: warm, brief, respectful, and practical. Use plain English by default. If the user switches to Shona or Ndebele, respond simply in that language when able. Light terms like bho or sharp sharp are allowed only in low-risk chat. Never use slang during crisis. End normal replies with one practical next step.',
  },
];

export const goldFaqCards: KnowledgeCard[] = [
  {
    id: 'faq-self-harm-now',
    title: 'I want to hurt myself. What should I do right now?',
    category: 'emergency',
    tags: ['suicide', 'self harm', 'kuzviuraya', 'crisis'],
    riskLevel: 'red',
    content: 'I am really glad you told me. Please do not stay alone with this pain. Move away from anything you could use to hurt yourself, go near a trusted person if you can, and call Childline on 116 now. If you can use WhatsApp, Childline also publishes +263 719 116 116 and +263 732 116 116. If there is immediate danger, call 999.',
  },
  {
    id: 'faq-mutiriro-friend',
    title: 'My friend is smoking mutoriro every day and acting violent. What do I do?',
    category: 'substance-use',
    tags: ['mutoriro', 'crystal meth', 'violent', 'friend'],
    riskLevel: 'amber',
    content: 'Mutoriro can change how the brain works and can make someone paranoid, aggressive, or unsafe. Do not argue with your friend while they are high. Step away if they become violent. Tell a trusted adult, school counselor, clinic, or counselor. If someone collapses, has chest pain, or may overdose, get emergency medical help now.',
  },
  {
    id: 'faq-boyfriend-checks-phone',
    title: 'My boyfriend checks my phone and says it is love. Is this right?',
    category: 'wellness',
    tags: ['relationships', 'phone', 'jealousy', 'control'],
    riskLevel: 'green',
    content: 'No. Checking your phone and controlling who you speak to are not signs of love. Healthy love has trust, privacy, and respect. You can say: I care about you, but my phone and friendships are my private space. If his anger makes you scared, contact Musasa or Childline for safety help.',
  },
  {
    id: 'faq-uncle-bad-touch',
    title: 'My uncle touches my private parts and says keep it secret. What should I do?',
    category: 'emergency',
    tags: ['bad touch', 'uncle', 'abuse', 'private parts', 'childline'],
    riskLevel: 'red',
    content: 'This is abuse. You did nothing wrong. Do not keep this secret. Tell a trusted teacher, caregiver, or call Childline on 116 right now. If you are in danger, move toward a safe adult or public place. The Victim Friendly Unit can help children report abuse in a more private way.',
  },
  {
    id: 'faq-forced-marriage-16',
    title: 'I am 16 and my family wants me to marry an older man. Is it legal?',
    category: 'srhr',
    tags: ['forced marriage', 'child marriage', '16', 'law'],
    riskLevel: 'red',
    content: 'No. In Zimbabwe, marriage under 18 is illegal. The law is there to protect you. No one should force you to marry for money, family pressure, or custom. Please call Childline 116 or tell a trusted teacher or social worker so they can help protect you.',
  },
  {
    id: 'faq-abortion',
    title: 'My friend is pregnant and wants an abortion. Can she just go to hospital?',
    category: 'srhr',
    tags: ['pregnant', 'abortion', 'clinic', 'law'],
    riskLevel: 'amber',
    content: 'Zimbabwe abortion law is restricted and can be complex. The safe step is to speak to a clinic, counselor, Musasa, Adult Rape Clinic, or Childline if she is under 18 or the pregnancy followed force or abuse. Please do not try unsafe backyard abortion. It can cause heavy bleeding, infection, infertility, or death.',
  },
];

export const allZimbabweRagCards = [...goldFaqCards, ...zimbabweKnowledgeCards];
