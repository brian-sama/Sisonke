const required = ['DATABASE_URL', 'JWT_SECRET'] as const;

export function validateEnv() {
  const missing = required.filter((key) => !process.env[key]);
  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  if ((process.env.JWT_SECRET || '').length < 32) {
    throw new Error('JWT_SECRET must be at least 32 characters long');
  }
}

export function getAllowedOrigins() {
  const configured = process.env.ALLOWED_ORIGINS || process.env.FRONTEND_URL || 'http://localhost:5173';
  const origins: (string | RegExp)[] = configured.split(',').map((o) => o.trim()).filter(Boolean);
  
  // Add production domain
  if (!origins.includes('https://sisonke.mmpzmne.co.zw')) {
    origins.push('https://sisonke.mmpzmne.co.zw');
  }

  // Allow any localhost port only outside of production
  if (process.env.NODE_ENV !== 'production') {
    origins.push(/^http:\/\/localhost:\d+$/);
  }
  
  return origins;
}
